// Service Worker Bulls Burger - PWA & Push Notifications
const CACHE_NAME = 'bulls-burger-v1';
const ASSETS_STATIC = [
  '/',
  '/admin',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_STATIC).catch(() => {});
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Interceptor de requisições para PWA
self.addEventListener('fetch', (event) => {
  // Ignora requisições de API, WebSocket e Supabase do cache offline estático
  if (
    event.request.url.includes('/api/') || 
    event.request.url.includes('/ws') ||
    event.request.url.includes('supabase.co')
  ) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }
      return fetch(event.request).then((networkResponse) => {
        return networkResponse;
      }).catch(() => {
        // Fallback para navegação HTML quando offline
        if (event.request.mode === 'navigate') {
          return caches.match('/admin') || caches.match('/');
        }
      });
    })
  );
});

// Push notification do entregador e admin
self.addEventListener('push', (event) => {
  let dados = { titulo: 'Bulls Burger', corpo: 'Nova atualização.', url: '/admin' };
  try {
    dados = event.data.json();
  } catch {
    // usa o padrão acima se o payload não vier em JSON
  }

  event.waitUntil(
    self.registration.showNotification(dados.titulo, {
      body: dados.corpo,
      icon: '/icons/icon-192.png',
      badge: '/icons/icon-192.png',
      data: { url: dados.url || '/admin' }
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = event.notification.data?.url || '/admin';
  event.waitUntil(clients.openWindow(url));
});

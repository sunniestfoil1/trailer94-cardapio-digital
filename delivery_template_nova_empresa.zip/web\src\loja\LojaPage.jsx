import React, { useState, useEffect } from 'react';
import { Header } from './Header';
import { CategoriaTabs } from './CategoriaTabs';
import { CardProduto } from './CardProduto';
import { ModalProduto } from './ModalProduto';
import { BotaoSacolaFlutuante } from './BotaoSacolaFlutuante';
import { GavetaCarrinho } from './GavetaCarrinho';
import { CheckoutModal } from './CheckoutModal';
import { AcompanhamentoPedido } from './AcompanhamentoPedido';
import { RaspadinhaSorte } from './RaspadinhaSorte';
import { Flame, RefreshCw, Gift } from 'lucide-react';
import { EMPRESA_CONFIG } from '../empresa.config';

export function LojaPage({ initialPedidoId = null }) {
  const [infoLoja, setInfoLoja] = useState(null);
  const [categorias, setCategorias] = useState([]);
  const [destaques, setDestaques] = useState([]);
  const [carregando, setCarregando] = useState(true);

  const [busca, setBusca] = useState('');
  const [categoriaAtiva, setCategoriaAtiva] = useState(null);
  const [produtoSelecionado, setProdutoSelecionado] = useState(null);

  const [checkoutAberto, setCheckoutAberto] = useState(false);
  const [pedidoAcompanhandoId, setPedidoAcompanhandoId] = useState(initialPedidoId);
  const [raspadinhaAberta, setRaspadinhaAberta] = useState(false);
  const [cupomAtivo, setCupomAtivo] = useState(null);

  useEffect(() => {
    if (initialPedidoId) {
      setPedidoAcompanhandoId(initialPedidoId);
    }
  }, [initialPedidoId]);

  useEffect(() => {
    const handlePopState = () => {
      const match = window.location.pathname.match(/\/pedido\/([a-f0-9]+)/i);
      setPedidoAcompanhandoId(match ? match[1] : null);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  useEffect(() => {
    async function carregarDados() {
      try {
        const [resCardapio, resInfo] = await Promise.all([
          fetch('/api/cardapio'),
          fetch('/api/loja/info')
        ]);

        if (resCardapio.ok && resInfo.ok) {
          const cardapioData = await resCardapio.json();
          const infoData = await resInfo.json();

          setCategorias(cardapioData.categorias || []);
          setDestaques(cardapioData.destaques || []);
          setInfoLoja(infoData);
          if (cardapioData.categorias?.length > 0) {
            setCategoriaAtiva(cardapioData.categorias[0].id);
          }
        }
      } catch (err) {
        console.error('Falha ao carregar cardápio:', err);
      } finally {
        setCarregando(false);
      }
    }

    carregarDados();
  }, []);

  function handleSelecionarCategoria(catId) {
    setCategoriaAtiva(catId);
    const elemento = document.getElementById(`cat-${catId}`);
    if (elemento) {
      elemento.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  if (pedidoAcompanhandoId) {
    return (
      <AcompanhamentoPedido 
        pedidoId={pedidoAcompanhandoId} 
        onVoltarLoja={() => {
          window.history.pushState(null, '', '/');
          setPedidoAcompanhandoId(null);
        }} 
      />
    );
  }

  if (carregando) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 text-white">
        <RefreshCw className="w-10 h-10 text-amber-400 animate-spin mb-4" />
        <p className="font-bold text-base">Preparando o cardápio do Bulls Burger...</p>
      </div>
    );
  }

  // Filtragem pela busca
  const categoriasFiltradas = categorias.map(cat => ({
    ...cat,
    produtos: cat.produtos.filter(p => {
      if (!busca.trim()) return true;
      const termo = busca.toLowerCase();
      return (
        p.nome.toLowerCase().includes(termo) ||
        (p.descricao && p.descricao.toLowerCase().includes(termo)) ||
        (p.ingredientes && p.ingredientes.toLowerCase().includes(termo))
      );
    })
  })).filter(cat => cat.produtos.length > 0);

  return (
    <div 
      className="min-h-screen pb-28 text-slate-100 relative bg-[#0a0d14]"
      style={{
        backgroundImage: "url('/imagens/origem/instagram/269.jpg')",
        backgroundRepeat: 'repeat',
        backgroundSize: '420px',
      }}
    >
      {/* Overlay sutil para garantir legibilidade de alto contraste sobre o pattern */}
      <div className="absolute inset-0 bg-slate-950/75 pointer-events-none" />

      {/* Conteúdo da Loja */}
      <div className="relative z-10">
        {/* Topo / Header */}
        <Header infoLoja={infoLoja} busca={busca} setBusca={setBusca} />

        {/* Navegação Sticky de Categorias */}
        {!busca && (
          <CategoriaTabs 
            categorias={categorias} 
            categoriaAtiva={categoriaAtiva} 
            onSelecionarCategoria={handleSelecionarCategoria} 
          />
        )}

        {/* Conteúdo Principal */}
        <main className="max-w-4xl mx-auto px-4 py-8 space-y-10">
          {/* Banner de Destaques / Mais Pedidos (apenas se não houver busca ativa) */}
          {!busca && destaques.length > 0 && (
            <section className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-400/20 border border-amber-400/50 flex items-center justify-center text-amber-400">
                  <Flame className="w-5 h-5 fill-amber-400" />
                </div>
                <div>
                  <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                    Mais Pedidos do Bulls
                  </h2>
                  <div className="h-1 w-16 bg-amber-400 rounded-full mt-1"></div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {destaques.slice(0, 4).map((produto) => (
                  <CardProduto 
                    key={`destaque-${produto.id}`}
                    produto={produto}
                    onAbrirDetalhes={(p) => setProdutoSelecionado(p)}
                  />
                ))}
              </div>
            </section>
          )}

          {/* Seções por Categoria */}
          {categoriasFiltradas.length === 0 ? (
            <div className="bg-slate-900/90 rounded-2xl p-8 text-center text-slate-400 border-2 border-slate-800 shadow-xl">
              <p className="font-bold text-lg text-white">Nenhum produto encontrado</p>
              <p className="text-sm text-slate-400 mt-1">Tente pesquisar por outro termo ou ingrediente.</p>
            </div>
          ) : (
            categoriasFiltradas.map((cat) => (
              <section key={cat.id} id={`cat-${cat.id}`} className="space-y-4 scroll-mt-20">
                <div className="border-b-2 border-slate-800/90 pb-2.5 flex items-baseline justify-between">
                  <div>
                    <h2 className="text-lg sm:text-xl font-black text-white tracking-wide">
                      {cat.nome}
                    </h2>
                    <div className="h-1 w-12 bg-amber-400 rounded-full mt-1.5"></div>
                  </div>
                  <span className="text-xs font-semibold text-slate-400">
                    {cat.produtos.length} {cat.produtos.length === 1 ? 'item' : 'itens'}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {cat.produtos.map((produto) => (
                    <CardProduto 
                      key={produto.id}
                      produto={produto}
                      onAbrirDetalhes={(p) => setProdutoSelecionado(p)}
                    />
                  ))}
                </div>
              </section>
            ))
          )}
        </main>
      </div>

      {/* Modal de Detalhes do Produto Selecionado */}
      {produtoSelecionado && (
        <ModalProduto 
          produto={produtoSelecionado} 
          onClose={() => setProdutoSelecionado(null)} 
        />
      )}

      {/* Botão Flutuante da Raspadinha da Sorte */}
      <button
        onClick={() => setRaspadinhaAberta(true)}
        className="fixed bottom-5 left-5 z-40 flex items-center gap-2 bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 text-slate-950 px-3.5 py-2.5 rounded-full shadow-2xl shadow-amber-500/40 border-2 border-white hover:scale-105 transition-transform active:scale-95 group cursor-pointer"
        title="Raspe e Ganhe seu Prêmio de Hoje!"
      >
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-600 opacity-75" />
          <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-600" />
        </span>
        <Gift className="w-4 h-4 text-slate-950 animate-bounce shrink-0" />
        <span className="font-black text-xs text-slate-950 tracking-tight">
          {cupomAtivo ? `Cupom: ${cupomAtivo.codigo}` : 'Raspadinha Bulls'}
        </span>
      </button>

      {/* Botão Flutuante da Sacola */}
      <BotaoSacolaFlutuante />

      {/* Gaveta Lateral da Sacola com Upsell Inteligente e Cupons */}
      <GavetaCarrinho 
        infoLoja={infoLoja}
        produtosDisponiveis={categorias.flatMap(c => c.produtos || [])}
        onIrParaCheckout={() => setCheckoutAberto(true)}
        onAbrirRaspadinha={() => setRaspadinhaAberta(true)}
        cupomAtivo={cupomAtivo}
        onAplicarCupom={(c) => setCupomAtivo(c)}
      />

      {/* Modal de Checkout */}
      {checkoutAberto && (
        <CheckoutModal 
          infoLoja={infoLoja}
          cupomAtivo={cupomAtivo}
          onClose={() => setCheckoutAberto(false)}
          onPedidoCriado={(id) => {
            setCheckoutAberto(false);
            window.history.pushState(null, '', `/pedido/${id}`);
            setPedidoAcompanhandoId(id);
          }}
        />
      )}

      {/* Modal Interativo da Raspadinha da Sorte */}
      {raspadinhaAberta && (
        <RaspadinhaSorte
          onFechar={() => setRaspadinhaAberta(false)}
          onAplicarCupom={(cod) => {
            // Aplica instantaneamente o cupom sorteado
            if (cod === 'BULLS10') {
              setCupomAtivo({
                codigo: 'BULLS10',
                desconto: 1000,
                tipo: 'valor_fixo',
                descricao: 'R$ 10,00 OFF'
              });
            } else if (cod === 'FRETEFREE') {
              setCupomAtivo({
                codigo: 'FRETEFREE',
                desconto: 0,
                tipo: 'frete_gratis',
                descricao: 'Frete Grátis'
              });
            } else {
              setCupomAtivo({
                codigo: 'BULLS5',
                desconto: 500,
                tipo: 'valor_fixo',
                descricao: 'R$ 5,00 OFF'
              });
            }
          }}
        />
      )}
    </div>
  );
}

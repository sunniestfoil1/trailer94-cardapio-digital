import React, { useState } from 'react';
import { DollarSign, TrendingUp, PieChart, ShoppingBag, Percent, ArrowUpRight, ShieldCheck, Download } from 'lucide-react';
import { formatarPreco } from '../compartilhado/formatadores';

export function PainelFinanceiroCMV({ metricas, pedidos }) {
  const [cmvPercentual, setCmvPercentual] = useState(32); // 32% padrão de hamburgueria artesanal

  const totalPedidos = metricas?.pedidosHoje?.total_pedidos || pedidos.length || 0;
  const faturamentoTotal = metricas?.pedidosHoje?.faturamento_total || pedidos.reduce((acc, p) => acc + (p.total || 0), 0);
  const ticketMedio = totalPedidos > 0 ? Math.round(faturamentoTotal / totalPedidos) : 0;

  // Repasses para motoboy
  const totalRepasseMotoboys = pedidos.filter(p => p.status === 'entregue' || p.motoboy_id).length * 600;

  // CMV estimado
  const custoInsumosEstimado = Math.round(faturamentoTotal * (cmvPercentual / 100));

  // Lucro bruto e margem líquida
  const lucroBrutoEstimado = Math.max(0, faturamentoTotal - custoInsumosEstimado - totalRepasseMotoboys);
  const margemLucroLiquida = faturamentoTotal > 0 ? Math.round((lucroBrutoEstimado / faturamentoTotal) * 100) : 0;

  // Estatística de pagamento
  const contagemPagamento = pedidos.reduce((acc, p) => {
    const metodo = p.forma_pagamento || 'pix';
    acc[metodo] = (acc[metodo] || 0) + 1;
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-black text-white flex items-center gap-2">
            <span>DRE Operacional & CMV — Bulls Burger</span>
            <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30 font-bold">
              Lucro Real em Tempo Real
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Cálculo instantâneo de margens, custo de mercadoria vendida e resultado líquido da noite.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 p-1.5 rounded-xl text-xs">
          <span className="text-slate-400 pl-2">Ajustar CMV:</span>
          <select
            value={cmvPercentual}
            onChange={(e) => setCmvPercentual(Number(e.target.value))}
            className="bg-slate-800 text-amber-400 font-black rounded-lg px-2.5 py-1 border border-slate-700 focus:outline-none"
          >
            <option value={28}>28% (Super Econômico)</option>
            <option value={32}>32% (Padrão Artesanal)</option>
            <option value={36}>36% (Insumos Premium)</option>
            <option value={40}>40% (Margem Baixa)</option>
          </select>
        </div>
      </div>

      {/* Cartões Executivos */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-1">
          <span className="text-xs text-slate-400 flex items-center justify-between">
            <span>Faturamento Bruto</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </span>
          <p className="text-2xl font-black text-emerald-400">
            {formatarPreco(faturamentoTotal)}
          </p>
          <span className="text-[10px] text-slate-500 block">Total faturado no período</span>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-1">
          <span className="text-xs text-slate-400 flex items-center justify-between">
            <span>Ticket Médio</span>
            <TrendingUp className="w-4 h-4 text-amber-400" />
          </span>
          <p className="text-2xl font-black text-amber-400">
            {formatarPreco(ticketMedio)}
          </p>
          <span className="text-[10px] text-slate-500 block">Média por cliente atendido</span>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-1">
          <span className="text-xs text-slate-400 flex items-center justify-between">
            <span>Custo Insumos (CMV {cmvPercentual}%)</span>
            <Percent className="w-4 h-4 text-red-400" />
          </span>
          <p className="text-2xl font-black text-red-400">
            - {formatarPreco(custoInsumosEstimado)}
          </p>
          <span className="text-[10px] text-slate-500 block">Carne, pão, queijo e embalagens</span>
        </div>

        <div className="bg-gradient-to-br from-emerald-500/20 via-slate-900 to-slate-900 border-2 border-emerald-500/40 rounded-2xl p-4 space-y-1 shadow-lg">
          <span className="text-xs text-emerald-300 font-bold flex items-center justify-between">
            <span>Lucro Líquido Operacional</span>
            <ArrowUpRight className="w-4 h-4 text-emerald-400" />
          </span>
          <p className="text-2xl font-black text-emerald-300">
            {formatarPreco(lucroBrutoEstimado)}
          </p>
          <span className="text-[10px] text-emerald-400/90 font-bold block">
            Margem Líquida Real: {margemLucroLiquida}%
          </span>
        </div>
      </div>

      {/* Tabela Demonstrativo DRE Simplificado */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
          <PieChart className="w-4 h-4 text-amber-400" />
          <span>Estrutura Financeira da Operação (DRE)</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="py-2.5 text-left">Rubrica / Linha Financeira</th>
                <th className="py-2.5 text-right">Percentual</th>
                <th className="py-2.5 text-right">Valor em Reais</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              <tr>
                <td className="py-3 text-white font-bold">(+) Receita Bruta de Vendas (Pedidos)</td>
                <td className="py-3 text-right text-slate-300">100,0%</td>
                <td className="py-3 text-right text-emerald-400 font-black">{formatarPreco(faturamentoTotal)}</td>
              </tr>
              <tr>
                <td className="py-3 text-slate-300">(-) Custo dos Insumos & Carnes (CMV Estimado)</td>
                <td className="py-3 text-right text-red-400">-{cmvPercentual},0%</td>
                <td className="py-3 text-right text-red-400 font-bold">- {formatarPreco(custoInsumosEstimado)}</td>
              </tr>
              <tr>
                <td className="py-3 text-slate-300">(-) Repasse de Corridas aos Motoboys (R$ 6/entrega)</td>
                <td className="py-3 text-right text-orange-400">
                  {faturamentoTotal > 0 ? `-${((totalRepasseMotoboys / faturamentoTotal) * 100).toFixed(1)}%` : '0%'}
                </td>
                <td className="py-3 text-right text-orange-400 font-bold">- {formatarPreco(totalRepasseMotoboys)}</td>
              </tr>
              <tr className="bg-slate-950/60 font-black">
                <td className="py-3.5 text-amber-300 text-sm">(=) RESULTADO OPERACIONAL LÍQUIDO DO PERÍODO</td>
                <td className="py-3.5 text-right text-emerald-400 text-sm">{margemLucroLiquida}%</td>
                <td className="py-3.5 text-right text-emerald-400 text-base">{formatarPreco(lucroBrutoEstimado)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Distribuição por Meio de Pagamento */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { id: 'pix', rotulo: 'PIX Instantâneo', cor: 'emerald' },
          { id: 'cartao_credito', rotulo: 'Cartão de Crédito', cor: 'blue' },
          { id: 'dinheiro', rotulo: 'Dinheiro em Espécie', cor: 'amber' }
        ].map(item => {
          const totalQtd = contagemPagamento[item.id] || 0;
          const pct = totalPedidos > 0 ? Math.round((totalQtd / totalPedidos) * 100) : 0;
          return (
            <div key={item.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
              <span className="text-xs text-slate-400">{item.rotulo}</span>
              <div className="flex items-baseline justify-between mt-2">
                <span className="text-xl font-black text-white">{totalQtd} pedidos</span>
                <span className="text-xs font-bold text-amber-400">{pct}%</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2 overflow-hidden">
                <div 
                  className="bg-amber-400 h-full rounded-full" 
                  style={{ width: `${pct}%` }} 
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

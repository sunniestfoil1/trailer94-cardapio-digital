/**
 * ========================================================
 * 🍔 CONFIGURAÇÃO CENTRAL DA EMPRESA (WHITE-LABEL)
 * ========================================================
 * Para personalizar este delivery para um novo cliente em minutos:
 * A IA ou desenvolvedor só precisa alterar os campos abaixo!
 */

export const EMPRESA_CONFIG = {
  // Dados Principais
  nome: 'Burguer Delivery',
  slug: 'burguer-delivery',
  slogan: 'Hambúrgueres Artesanais & Delivery Rápido',
  subtitulo: 'Pão brioche selado na manteiga, carnes nobres e molhos especiais.',
  
  // Localização & Contato
  cidade: 'Cascavel',
  estado: 'PR',
  enderecoCompleto: 'Av. Brasil, 1500 - Centro, Cascavel - PR',
  telefone: '(45) 99999-9999',
  whatsapp: '45999999999',
  instagram: '@deliveryartesanal',
  
  // Operação & Delivery
  horarioFuncionamento: 'Terça a Domingo das 18h às 23h30',
  tempoEstimadoEntrega: '35 a 50 min',
  taxaEntregaCentavos: 700, // R$ 7,00
  freteGratisApartirDeCentavos: 8000, // R$ 80,00 (0 para desativar)
  
  // Cores & Identidade Visual
  corPrimaria: '#f59e0b', // Amber
  corSecundaria: '#ea580c', // Orange
  corFundo: '#020617', // Slate 950 Dark
  
  // Credenciais Padrão Auto-Geradas
  admin: {
    nome: 'Gerente da Loja',
    email: 'admin@delivery.com.br',
    senhaPadrao: 'admin2026'
  },
  motoboy: {
    nome: 'Carlos Entregador',
    usuario: 'carlos@delivery.com.br',
    senhaPadrao: 'motoboy2026',
    pinPadrao: '1234'
  }
};

/**
 * Função utilitária para gerar e-mails e senhas amigáveis com base no nome da empresa
 * Exemplo: gerarCredenciaisEmpresa("Texas Smash Burger") -> admin@texassmash.com.br
 */
export function gerarCredenciaisEmpresa(nomeEmpresa = 'Burguer Delivery') {
  const slug = nomeEmpresa
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '');

  const primeiroNome = slug.slice(0, 12);

  return {
    adminEmail: `admin@${primeiroNome}.com.br`,
    adminSenha: `${primeiroNome}2026`,
    motoboyUsuario: `carlos@${primeiroNome}.com.br`,
    motoboySenha: `motoboy2026`,
    motoboyPin: '4321'
  };
}

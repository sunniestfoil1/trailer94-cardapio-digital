/**
 * 🍔 Script de Inicialização e Povoamento do Banco de Dados para Nova Empresa
 * 
 * Cria as categorias iniciais, produtos exemplo, usuário administrador e motoboy.
 * Uso:
 *   node scripts/popular_nova_empresa.js
 *   node scripts/popular_nova_empresa.js --nome "Texas Smash" --cidade "Curitiba"
 */

import db from '../db/db.js';
import { hashSenha } from '../auth/senha.js';

const args = process.argv.slice(2);
function getArg(chave, padrao) {
  const idx = args.indexOf(`--${chave}`);
  if (idx !== -1 && args[idx + 1]) return args[idx + 1];
  return padrao;
}

const NOME_EMPRESA = getArg('nome', 'Burguer Delivery');
const CIDADE = getArg('cidade', 'São Paulo - SP');

console.log('====================================================');
console.log(`🚀 INICIALIZANDO BANCO DE DADOS PARA: ${NOME_EMPRESA}`);
console.log('====================================================\n');

async function seed() {
  try {
    // 1. Categorias
    console.log('📁 Criando categorias...');
    const categorias = [
      { nome: '🔥 Smash Burgers', icone: 'flame', ordem: 1 },
      { nome: '🍔 Burgers Especiais', icone: 'burger', ordem: 2 },
      { nome: '🍟 Porções & Acompanhamentos', icone: 'fries', ordem: 3 },
      { nome: '🥤 Bebidas Geladas', icone: 'drink', ordem: 4 }
    ];

    const catIds = {};
    for (const cat of categorias) {
      let existente = await db.prepare('SELECT id FROM categorias WHERE nome = ?').get(cat.nome);
      if (!existente) {
        const res = await db.prepare('INSERT INTO categorias (nome, icone, ordem, ativa) VALUES (?, ?, ?, 1) RETURNING id')
          .run(cat.nome, cat.icone, cat.ordem);
        catIds[cat.nome] = res.lastInsertRowid;
      } else {
        catIds[cat.nome] = existente.id;
      }
    }

    // 2. Produtos Iniciais
    console.log('🍔 Cadastrando produtos iniciais...');
    const produtos = [
      {
        cat: '🔥 Smash Burgers',
        nome: 'Smash Bacon Supreme',
        descricao: 'Dois blends 90g com crostinha crocante, queijo cheddar inglês derretido, fatias de bacon e maionese no pão brioche tostado.',
        preco: 3290,
        destaque: 1,
        imagem: '/imagens/origem/instagram/baixada-1.jpg'
      },
      {
        cat: '🔥 Smash Burgers',
        nome: 'Classic Cheese Smash',
        descricao: 'Dois blends prensados de 90g, queijo prato derretido, cebola chapeada e molho clássico.',
        preco: 2890,
        destaque: 1,
        imagem: '/imagens/origem/instagram/baixada-2.jpg'
      },
      {
        cat: '🍔 Burgers Especiais',
        nome: 'Monster Cheddar Duplo',
        descricao: 'Burger artesanal 180g grelhado no fogo, piscina de cheddar cremoso, cebola caramelizada e farofa de bacon no pão australiano.',
        preco: 3990,
        destaque: 1,
        imagem: '/imagens/origem/instagram/baixada-4.jpg'
      },
      {
        cat: '🍟 Porções & Acompanhamentos',
        nome: 'Batata Rústica com Alecrim e Parmesão',
        descricao: 'Batatas crocantes temperadas com alecrim fresco e queijo ralado na hora. Acompanha maionese verde artesanal.',
        preco: 2490,
        destaque: 1,
        imagem: '/imagens/demo/batata-frita.jpg'
      },
      {
        cat: '🥤 Bebidas Geladas',
        nome: 'Refrigerante Lata 350ml',
        descricao: 'Coca-Cola, Guaraná Antarctica ou Fanta geladíssima.',
        preco: 650,
        destaque: 0,
        imagem: '/imagens/demo/refrigerante-lata.jpg'
      }
    ];

    for (const prod of produtos) {
      const catId = catIds[prod.cat] || 1;
      let existente = await db.prepare('SELECT id FROM produtos WHERE nome = ?').get(prod.nome);
      let prodId;
      if (!existente) {
        const res = await db.prepare(`
          INSERT INTO produtos (categoria_id, nome, descricao, preco_base, destaque, ativo, ordem)
          VALUES (?, ?, ?, ?, ?, 1, 1) RETURNING id
        `).run(catId, prod.nome, prod.descricao, prod.preco, prod.destaque);
        prodId = res.lastInsertRowid;
      } else {
        prodId = existente.id;
      }

      // Adiciona imagem do produto
      await db.prepare('DELETE FROM produto_imagens WHERE produto_id = ?').run(prodId);
      await db.prepare('INSERT INTO produto_imagens (produto_id, arquivo, ordem, principal) VALUES (?, ?, 0, 1)')
        .run(prodId, prod.imagem);
    }

    // 3. Usuário Administrador
    console.log('👤 Configurando usuário Administrador...');
    const slugEmpresa = NOME_EMPRESA.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 12);
    const adminEmail = `admin@${slugEmpresa}.com.br`;
    const adminSenha = `${slugEmpresa}2026`;
    const hashAdmin = await hashSenha(adminSenha);

    await db.prepare(`
      INSERT INTO usuarios (nome, email, senha_hash, papel)
      VALUES (?, ?, ?, 'dono')
      ON CONFLICT (email) DO UPDATE SET senha_hash = excluded.senha_hash
    `).run(`Gerente - ${NOME_EMPRESA}`, adminEmail, hashAdmin);

    // 4. Entregador / Motoboy
    console.log('🏍️ Configurando Entregador padrão...');
    const motoUsuario = `carlos@${slugEmpresa}.com.br`;
    const motoSenha = 'motoboy2026';
    const hashMoto = await hashSenha(motoSenha);

    await db.prepare(`
      INSERT INTO motoboys (nome, telefone, usuario, senha_hash, status, veiculo)
      VALUES (?, ?, ?, ?, 'ativo', 'Honda CG 160 Fan')
      ON CONFLICT (usuario) DO UPDATE SET senha_hash = excluded.senha_hash, status = 'ativo'
    `).run('Carlos Entregador', '+55 11 99999-4321', motoUsuario, hashMoto);

    console.log('\n====================================================');
    console.log('✅ BANCO DE DADOS POVOADO COM SUCESSO!');
    console.log('====================================================');
    console.log(`📌 Admin: ${adminEmail} | Senha: ${adminSenha}`);
    console.log(`📌 Motoboy: ${motoUsuario} | Senha: ${motoSenha} | PIN: 4321`);
    console.log('====================================================\n');
    process.exit(0);
  } catch (err) {
    console.error('❌ Erro durante seed:', err);
    process.exit(1);
  }
}

seed();
